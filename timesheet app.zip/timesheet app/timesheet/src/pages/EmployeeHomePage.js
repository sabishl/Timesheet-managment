import React,{Fragment} from 'react';


export default function EmployeeHomePage(){

    return <Fragment>

<div className="centered-text">
  <div className="text-wrapper">
    <h2>Welcome to Employee Dashboard</h2>
  
    <h3>Update the Projects.</h3>
  </div>
</div>


    </Fragment>
    
};