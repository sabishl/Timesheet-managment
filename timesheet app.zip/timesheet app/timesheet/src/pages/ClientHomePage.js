import React,{Fragment} from 'react';
export default function ClientHomePage(){

    return <Fragment>

<div className="centered-text">
  <div className="text-wrapper">
    <h2>Welcome to Client Dashboard</h2>
             
    <h3>See Your Projects Details.</h3>
  </div>
</div>


    </Fragment>
    
};