import React,{Fragment} from 'react';

export default function Home(){

    return <Fragment>

<div className="centered-text">
  <div className="text-wrapper">
    <h2>Welcome to Admin Dashboard</h2>
             
    <h3>Manage the projects efficiently.</h3>
  </div>
</div>

    </Fragment>
    
};