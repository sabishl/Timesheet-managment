import React, { Fragment, useState,useEffect} from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function CreateProject() {
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    // Get user email from session storage
    const user = sessionStorage.getItem('user');
    if (user) {
      const userData = JSON.parse(user);
      setUserEmail(userData.email);
      console.log(userEmail);
    }
  }, [userEmail]);
  const [formData, setFormData] = useState({
    name: '',
    client_name:'',
    address:'',
    project_status: 'accepted',
    department: '',
    business_unit: '',
    employees: [],
    tasks:[],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic form validation
    if (!formData.name || !formData.client_name || !formData.address || !formData.department || !formData.business_unit) {
      toast.error('All fields are required');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8000/api/v1/project_requests', formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        toast('Project created successfully');
        console.log(response.data);
        // Clear form after successful project creation
        setFormData({
          name: '',
          client_name:'',
          address:'',
          project_status: 'None',
          department: '',
          business_unit: '',
          employees: [],
          tasks:[],
        });
      } else {
        toast.error('Failed to create project');
        console.log(response.data);
      }
    } catch (error) {
      console.error('Error creating project:', error);
      toast.error('Internal server error');
    }
  };

  return (
    <Fragment>
      <div className="login-container">
        <h2>Create Project</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input 
              type="text" 
              id="name" 
              name="name" 
              value={formData.name} 
              onChange={handleChange} 
              placeholder="Enter project name" 
              className='inp' 
              required 
            />
          </div>
          <div className="form-group">
            <label htmlFor="clientName">Client Name:</label>
            <input 
              type="text" 
              id="client_name" 
              name="client_name" 
              value={formData.client_name} 
              onChange={handleChange} 
              placeholder="Enter client name" 
              className='inp' 
              required 
            />
          </div>
          <div className="form-group">
            <label htmlFor="description">Address:</label>
            <textarea 
              id="sddress" 
              name="address" 
              value={formData.address} 
              onChange={handleChange} 
              placeholder="Enter client address"
              className='inp' 
              required 
            />
          </div>
          <div className="form-group">
            <label htmlFor="department">Department:</label>
            <select 
              id="department" 
              name="department" 
              value={formData.department} 
              onChange={handleChange} 
              className='inp' 
              required
            >
              <option value="">Select user type</option>
              <option value="A">A</option>
              <option value="B">B</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="business_unit">Business Unit:</label>
            <select 
              id="business_unit" 
              name="business_unit" 
              value={formData.business_unit} 
              onChange={handleChange} 
              className='inp' 
              required
            >
              <option value="">Select user type</option>
              <option value="A">A</option>
              <option value="B">B</option>
            </select>
          </div>
          <button type="submit" className="create-account-btn">Create Project</button>
        </form>
      </div>
      <ToastContainer />
    </Fragment>
  );
}
