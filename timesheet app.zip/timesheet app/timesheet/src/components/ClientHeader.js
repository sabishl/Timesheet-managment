import { NavLink } from 'react-router-dom';

export default function ClientHeader() {


  return (
    <header className="header">
      <div className="container">
        <div className="header-left">
          <h1>Time sheet Management System</h1>
        </div>
        <nav className="header-right">
          <ul>
            <li>
              <NavLink
                to="/your-projects"
                activeClassName="active"
              >
                Your Projects
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/project-requests"
                activeClassName="active"
              >
                New Project
              </NavLink>
            </li>
            <li>
              <NavLink
                to="/"
                activeClassName="active"
              >
                Logout
              </NavLink>

            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}
