const NewProjectModel = require('../models/projectModel');

exports.createProjectRequest = async (req, res, next) => {
    try {
        const {
            name,
            client_name,
            address,
            project_status,
            department,
            business_unit,
            employees,
            tasks,
        } = req.body;

        // Ensure tasks is an array of objects with task_name and hours
        if (!Array.isArray(tasks) || !tasks.every(task => task.task_name && task.hours)) {
            return res.status(400).json({
                success: false,
                message: 'Tasks must be an array of objects with task_name and hours',
            });
        }

        const newProject = await NewProjectModel.create({
            name,
            client_name,
            address,
            project_status,
            department,
            business_unit,
            employees, // Assuming employees is already an array of objects with emp_email
            tasks, // This will directly store the tasks array
        });

        res.json({
            success: true,
            newProject,
        });
    } catch (error) {
        console.error('Error creating project request:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
};


exports.updateStatus = async (req, res, next) => {
    try {
        const { new_status } = req.body; 
        const updatedProject = await NewProjectModel.findByIdAndUpdate(
            req.params.id,
            { $set: { status: new_status } },
            { new: true } 
        );

        if (!updatedProject) {
            return res.status(404).json({
                success: false,
                message: 'No project found with that ID'
            });
        }

        res.json({
            success: true,
            updatedProject
        });
    } catch (error) {
        console.error('Error updating project status:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};