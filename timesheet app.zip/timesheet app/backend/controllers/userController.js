const UserModel=require('../models/userModel');

exports.createUserRequest = async (req, res, next) => {
    try {

        const { name, email, phone, department,business_unit, userType, password } = req.body;

        if (!name || !email || !phone || !department || !business_unit || !userType || !password) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        const newUser = await UserModel.create({
            name,
            email,
            phone,
            department,
            business_unit,
            userType,
            password
        });


        res.json({
            success: true,
            newUser
        });
    } catch (error) {
        console.error('Error creating user account:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};


exports.getUser=async(req,res,next)=>{
    try{
     const users=await UserModel.find();
     res.json({
         success:true,
         users
     })
   }
   catch(error)
     {
      res.status(404).json({
         success:false,
         message:'Unable to get users'
      })   
     }
 };
