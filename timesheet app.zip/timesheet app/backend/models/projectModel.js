const mongoose=require('mongoose');

const projectSchema=new mongoose.Schema({
    name:String,
    client_name:String,
    address:String,
    project_status:String,
    department:String,
    business_unit:String,
    employees:[
        {
            emp_email:String,
        }
    ],
});

const projectModel=mongoose.model('Project',projectSchema);

module.exports=projectModel;