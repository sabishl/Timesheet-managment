const express=require('express');
const { createProjectRequest } = require('../controllers/projectRequestController');
const router=express.Router();

router.route('/project_requests').post(createProjectRequest);

module.exports=router;