const express = require('express');
const { getProjects, getSingleProject, getOngoingProjects, getCompletedProjects, getProjectsWithEmail } = require('../controllers/projectController');
const { updateStatus } = require('../controllers/projectRequestController');
const { addEmployee, updateProjectStatus, addTask } = require('../controllers/projectUpdateController');

const router=express.Router();

router.route('/projects').get(getProjects);
router.route('/projects/:id').get(getSingleProject);
router.route('/projects/:id').put(updateStatus);
router.route('/projects/:id').post(addEmployee);


router.route('/ongoing-projects').get(getOngoingProjects);
router.route('/ongoing-projects/:id').get(getSingleProject);
router.route('/ongoing-projects/:id').put(updateStatus);
router.route('/ongoing-projects/:id').post(addEmployee);

router.route('/completed-projects').get(getCompletedProjects);
router.route('/completed-projects/:id').get(getSingleProject);
router.route('/completed-projects/:id').put(updateStatus);
router.route('/completed-projects/:id').post(addEmployee);

router.route('/your-projects').get(getProjectsWithEmail);
router.route('/your-projects/:id').get(getSingleProject);

router.route('/emp-projects').get(getProjectsWithEmail);
router.route('/emp-projects/:id').get(getSingleProject);
router.route('/emp-projects/:id').put(updateProjectStatus);
module.exports=router;
