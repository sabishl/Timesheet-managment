const express=require('express');
const { createUserRequest } = require('../controllers/userController');
const router=express.Router();

router.route('/create-account').post(createUserRequest);

module.exports=router;